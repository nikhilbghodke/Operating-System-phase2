package com.company;

public class PCB {
    int TTL,TLL,TLC,TTC;

    public PCB(int line,int time){
        TLC=0;
        TTC=0;
        TTL=time;
        TLL=line;
    }
}
